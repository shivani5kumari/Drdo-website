<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "officer") {
    header("Location: ../login/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Officer Dashboard</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="dashboard">
        <h3>Officer Dashboard</h3>
        <ul>
            <li><a href="../complaint/manage.php">Check & Manage Complaints</a></li>
        </ul>
    </div>
</body>
</html>
