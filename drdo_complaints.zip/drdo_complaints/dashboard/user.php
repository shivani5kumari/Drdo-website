<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "user") {
    header("Location: ../login/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="dashboard">
        <h3>User Dashboard</h3>
        <ul>
            <li><a href="../complaint/file.php">File a Complaint</a></li>
            <li><a href="../complaint/status.php">Check Complaint Status</a></li>
        </ul>
    </div>
</body>
</html>
