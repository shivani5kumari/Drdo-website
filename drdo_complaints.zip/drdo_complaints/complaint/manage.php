<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once("../config/db.php");

// Redirect if not officer
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'officer') {
    header("Location: ../login/login.php");
    exit();
}

// Fetch complaints from database
$sql = "SELECT * FROM complaints";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Complaints</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container">
        <h2>Manage Complaints - Officer: <?php echo $_SESSION['username']; ?></h2>
        <a href="../login/logout.php">Logout</a>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Designation</th>
                <th>Group</th>
                <th>Complaint Type</th>
                <th>Details</th>
                <th>Status</th>
                <th>Feedback</th>
                <th>Remark</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row['id']; ?></td>
    <td><?= htmlspecialchars($row['user_group']); ?></td>
    <td><?= htmlspecialchars($row['username']); ?></td>
    <td><?= htmlspecialchars($row['designation']); ?></td>
    <td><?= htmlspecialchars($row['complaint_details']); ?></td>
    <form method="POST" action="update_complaint.php">
        <td>
            <select name="status" required>
                <option value="Viewed" <?= $row['status'] == 'Viewed' ? 'selected' : '' ?>>Viewed</option>
                <option value="Pending" <?= $row['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                <option value="Completed" <?= $row['status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
            </select>
        </td>
        <td><input type="text" name="feedback" value="<?= htmlspecialchars($row['feedback']); ?>" required></td>
        <td><input type="text" name="remark" value="<?= htmlspecialchars($row['remark']); ?>" required></td>
        <td>
            <input type="hidden" name="complaint_id" value="<?= $row['id']; ?>">
            <button type="submit">Update</button>
        </td>
    </form>
</tr>
<?php endwhile; ?>

        </table>
    </div>
</body>
</html>
