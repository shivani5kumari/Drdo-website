<?php
session_start();
require_once("../config/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $complaint_id = $_POST['complaint_id'];
    $status = $_POST['status'];
    $feedback = $_POST['feedback'];
    $remark = $_POST['remark'];

    $sql = "UPDATE complaints SET status = ?, feedback = ?, remark = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $status, $feedback, $remark, $complaint_id);

    if ($stmt->execute()) {
        header("Location: manage.php");
        exit();
    } else {
        echo "Error updating complaint.";
    }
}
?>
