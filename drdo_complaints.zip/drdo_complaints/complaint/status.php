<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login/login.php");
    exit();
}

require_once("../config/db.php");

$username = $_SESSION['username'];

$sql = "SELECT complaint_type, complaint_details, status, feedback, remark, created_at 
        FROM complaints 
        WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Check Complaint Status - DRDO Complaints</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="dashboard">
        <h2>My Complaints</h2>
        <a href="../user/user.php">← Back to Dashboard</a>
        <table border="1">
            <thead>
                <tr>
                    <th>Complaint Type</th>
                    <th>Details</th>
                    <th>Status</th>
                    <th>Feedback</th>
                    <th>Remark</th>
                    <th>Submitted At</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['complaint_type']); ?></td>
                    <td><?= htmlspecialchars($row['complaint_details']); ?></td>
                    <td><?= htmlspecialchars($row['status']); ?></td>
                    <td><?= htmlspecialchars($row['feedback']); ?></td>
                    <td><?= htmlspecialchars($row['remark']); ?></td>
                    <td><?= htmlspecialchars($row['created_at']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
