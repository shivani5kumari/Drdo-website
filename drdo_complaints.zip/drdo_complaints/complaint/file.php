<?php
session_start();
require_once("../config/db.php");

// If user is not logged in, redirect to login
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login/login.php");
    exit();
}

$username = $_SESSION['username'];
$designation = $_SESSION['designation'];
$group = $_SESSION['user_group'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $complaint_type = $_POST['complaint_type'];
    $complaint_details = $_POST['complaint_details'];

    $sql = "INSERT INTO complaints (username, designation, user_group, complaint_type, complaint_details)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $username, $designation, $group, $complaint_type, $complaint_details);

    if ($stmt->execute()) {
        $success = "Complaint filed successfully!";
    } else {
        $error = "Error submitting complaint.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>File a Complaint</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="form-container">
        <h2>File a Complaint</h2>
        <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

        <form method="POST">
            <label>Username:</label><br>
            <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" readonly><br>

            <label>Designation:</label><br>
            <input type="text" name="designation" value="<?php echo htmlspecialchars($designation); ?>" readonly><br>

            <label>Group:</label><br>
            <input type="text" name="group" value="<?php echo htmlspecialchars($group); ?>" readonly><br>

            <label>Complaint Type:</label><br>
            <select name="complaint_type" required>
                <option value="">Select Type</option>
                <option value="Infrastructure">Infrastructure</option>
                <option value="Electrical">Electrical</option>
                <option value="Technical">Technical</option>
                <option value="Sanitation">Sanitation</option>
                <option value="Other">Other</option>
            </select><br>

            <label>Complaint Details:</label><br>
            <textarea name="complaint_details" rows="5" required></textarea><br>

            <button type="submit">Submit Complaint</button>
        </form>
    </div>
</body>
</html>
