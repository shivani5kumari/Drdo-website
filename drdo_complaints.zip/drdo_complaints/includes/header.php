<?php
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION["username"])) {
    header("Location: ../login/login.php");
    exit();
}
?>

<div class="header">
    <div class="left">
        <h2>Welcome, <?= $_SESSION["username"]; ?></h2>
    </div>
    <div class="right">
        <a href="../login/logout.php">Logout</a>
    </div>
</div>
<hr>
