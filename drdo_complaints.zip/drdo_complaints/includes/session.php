<?php
session_start();

if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    // Redirect to login page if not logged in
    header("Location: ../login/login.php");
    exit();
}
