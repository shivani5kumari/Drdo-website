<?php
require_once("../config/db.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $id = $_POST['complaint_id'];
    $status = $_POST['status'];
    $remark = $_POST['remark'];
    $feedback = $_POST['feedback'];

    $sql = "UPDATE complaints SET status = ?, remark = ?, feedback = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $status, $remark, $feedback, $id);

    if ($stmt->execute()) {
        header("Location: officer.php");
        exit();
    } else {
        echo "Failed to update complaint.";
    }
}
?>
