<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once("../config/db.php");

// Check if officer is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'officer') {
    header("Location: ../login/login.php");
    exit();
}

$sql = "SELECT * FROM complaints";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Officer Dashboard</title>
</head>
<body>
    <h2>Welcome Officer <?php echo $_SESSION['username']; ?></h2>
    <a href="../login/logout.php">Logout</a>
    <h3>Complaint List</h3>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Complaint Type</th>
            <th>Status</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['username'] ?></td>
                <td><?= $row['complaint_type'] ?></td>
                <td><?= $row['status'] ?></td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>
