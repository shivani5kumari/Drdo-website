<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Login - DRDO Complaints</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form method="POST" action="auth.php">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <select name="role" required>
                <option value="">Select Role</option>
                <option value="user">User</option>
                <option value="officer">Officer</option>
            </select><br>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
