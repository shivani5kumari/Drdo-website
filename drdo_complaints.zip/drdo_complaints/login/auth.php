<?php
session_start();
require_once "../config/db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $role = $_POST["role"];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND role = ?");
    $stmt->bind_param("ss", $username, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if ($user['password'] === $password) {
            $_SESSION["username"] = $user["username"];
            $_SESSION["role"] = $user["role"];
            $_SESSION["designation"] = $user["designation"];
            $_SESSION["user_group"] = $user["user_group"];

            if ($role === "user") {
                header("Location: ../dashboard/user.php");
            } else if ($role === "officer") {
                header("Location: ../dashboard/officer.php");
            } else {
                echo "Invalid role assigned.";
            }
        } else {
            echo "❌ Incorrect password!";
        }
    } else {
        echo "❌ Invalid login credentials!";
    }
}
?>
