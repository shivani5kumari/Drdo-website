<?php
echo "DRDO Complaint Portal is working.";
?>
